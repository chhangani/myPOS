package com.ntl.pos.utill;

import java.sql.Connection;

public interface DBUtil {
	 public int getDBConnection(String driverType);
}
