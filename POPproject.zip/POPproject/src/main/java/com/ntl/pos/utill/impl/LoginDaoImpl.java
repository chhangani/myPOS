package com.ntl.pos.utill.impl;

import java.util.ArrayList;

import com.ntl.pos.bean.CredentialsBean;
import com.ntl.pos.utill.loginDao;

public class LoginDaoImpl implements loginDao{

	//@Override
	public String createLogin(CredentialsBean cb) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public int deleteLogin(ArrayList<String> Arr) {
		// TODO Auto-generated method stub
		return 0;
	}
	//@Override
	public boolean updateLogin(CredentialsBean cb) {
		// TODO Auto-generated method stub
		return false;
	}

	//@Override
	public CredentialsBean findByID(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	public ArrayList<CredentialsBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
